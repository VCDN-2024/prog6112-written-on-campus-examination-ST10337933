/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examquestion2;

import javax.swing.*; //(JavaPoint,2024)
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

// IMovieTickets Interface
interface IMovieTickets {
    double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice);
    boolean validateData(MovieTicketData movieTicketData);
}

// MovieTicketData Class
class MovieTicketData {
    private String movieName;
    private int numberOfTickets;
    private double ticketPrice;

    
    
    
    
    
    public MovieTicketData(String movieName, int numberOfTickets, double ticketPrice) {
        this.movieName = movieName;
        this.numberOfTickets = numberOfTickets;
        this.ticketPrice = ticketPrice;
    }//(w3schools,2024)
    
    
    
    
    

    public String getMovieName() { return movieName; }
    public int getNumberOfTickets() { return numberOfTickets; }
    public double getTicketPrice() { return ticketPrice; }
}//(w3schools,2024)

// MovieTickets Class
class MovieTickets implements IMovieTickets {
    private static final double VAT_RATE = 0.14;

    
    
    
    @Override
    public double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        return numberOfTickets * ticketPrice * (1 + VAT_RATE);
    }

    
    
    
    
    
    @Override
    public boolean validateData(MovieTicketData movieTicketData) {
        if (movieTicketData.getMovieName().isEmpty()) {
            return false;
        }
        if (movieTicketData.getTicketPrice() <= 0) {
            return false;
        }
        if (movieTicketData.getNumberOfTickets() <= 0) {
            return false;
        }
        return true;
    }//(w3schools,2024)
}





// The main GuI appliction starts from the below code 
public class ExamQuestion2 extends JFrame implements ActionListener {
    JComboBox<String> movieComboBox;
    private JTextField ticketPriceField;
    private JTextField ticketCountField;
    private JTextArea reportArea;

    private MovieTickets movieTickets;

    public ExamQuestion2() {
        movieTickets = new MovieTickets();

        setTitle("Cinema Ticket Sales");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        
        
        
        
        
        // Menu
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(this);
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearFields());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        
        
        
        
        
        
        // Form Panel with GridBagLayout
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Padding between components

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(new JLabel("Select Movie:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        movieComboBox = new JComboBox<>(new String[] {"Napoleon", "Oppenheimer", "Damsel"});
        movieComboBox.setPreferredSize(new Dimension(150, 25));
        formPanel.add(movieComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Ticket Price:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        ticketPriceField = new JTextField();
        ticketPriceField.setPreferredSize(new Dimension(100, 25));
        formPanel.add(ticketPriceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Number of Tickets:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        ticketCountField = new JTextField();
        ticketCountField.setPreferredSize(new Dimension(100, 25));
        formPanel.add(ticketCountField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        formPanel.add(new JLabel("Report:"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        reportArea = new JTextArea(5, 20);
        reportArea.setEditable(false);
        formPanel.add(new JScrollPane(reportArea), gbc);

        add(formPanel, BorderLayout.CENTER);
    }//the above code is for cutomsiing the text boxes and bringing them closer to the questions

    
    
    
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String movieName = (String) movieComboBox.getSelectedItem();
        int numberOfTickets;
        double ticketPrice;

        try {
            ticketPrice = Double.parseDouble(ticketPriceField.getText());
            numberOfTickets = Integer.parseInt(ticketCountField.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for ticket price and number of tickets.");
            return;
        }//(w3schools,2024)

        
        
        
        
        
        
        
        
        MovieTicketData data = new MovieTicketData(movieName, numberOfTickets, ticketPrice);

        if (!movieTickets.validateData(data)) {
            JOptionPane.showMessageDialog(this, "Invalid data. Please ensure all fields are correctly filled.");
            return;
        }//(w3schools,2024)

        
        
        
        
        
        
        
        double totalPrice = movieTickets.calculateTotalTicketPrice(numberOfTickets, ticketPrice);
        String formattedTotalPrice = String.format("%.2f", totalPrice);
        String report = "Movie: " + movieName + "\n" +
                        "Tickets: " + numberOfTickets + "\n" +
                        "Price per Ticket: " + ticketPrice + "\n" +
                        "Total Price (incl. VAT): " + formattedTotalPrice;

        reportArea.setText(report);
        saveReportToFile(report);
    } //(w3schools,2024)

    
    
    
    
    
    
    
    
    
    private void clearFields() {
        movieComboBox.setSelectedIndex(0);
        ticketPriceField.setText("");
        ticketCountField.setText("");
        reportArea.setText("");
    }//(codeacademy,2023)

    
    
    
    
    
    
    
    
    
    
    private void saveReportToFile(String report) {
        // This method writes the report text to a file named "report.txt"
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write(report);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving report to file.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ExamQuestion2().setVisible(true);
        }); //(w3schools,2024)
    }
}


/* 
Code Attribution
Javapoint,2024. Java Swing. Accessed online at: https://www.javatpoint.com/java-swing
w3schools,2024.Save Output To File. Accessed Online at: https://www.w3schools.com/java/java_files_create.asp
w3schools,2024.Java Math. accessed online at: https://www.w3schools.com/java/java_math.asp
W3schools, 2024. Java Booleans. Accessed online at: https://www.w3schools.com/java/java_booleans.asp
CodeAcademy, 2023.Clear Text fileds. Accessed ONline at: https://www.codecademy.com/resources/docs/java/calendar/clear
*/