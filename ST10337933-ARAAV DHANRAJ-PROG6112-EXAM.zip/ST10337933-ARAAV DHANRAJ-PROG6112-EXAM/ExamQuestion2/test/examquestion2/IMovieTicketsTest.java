/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package examquestion2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Araav
 */
public class IMovieTicketsTest {
    
    public IMovieTicketsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of calculateTotalTicketPrice method, of class IMovieTickets.
     */
    @Test
    public void testCalculateTotalTicketPrice() {
        System.out.println("calculateTotalTicketPrice");
        int numberOfTickets = 0;
        double ticketPrice = 0.0;
        IMovieTickets instance = new IMovieTicketsImpl();
        double expResult = 0.0;
        double result = instance.calculateTotalTicketPrice(numberOfTickets, ticketPrice);
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of validateData method, of class IMovieTickets.
     */
    @Test
    public void testValidateData() {
        System.out.println("validateData");
        MovieTicketData movieTicketData = null;
        IMovieTickets instance = new IMovieTicketsImpl();
        boolean expResult = false;
        boolean result = instance.validateData(movieTicketData);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IMovieTicketsImpl implements IMovieTickets {

        public double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
            return 0.0;
        }

        public boolean validateData(MovieTicketData movieTicketData) {
            return false;
        }
    }
    
}
