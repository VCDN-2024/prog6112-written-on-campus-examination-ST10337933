package examquestion2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;
import java.awt.event.ActionEvent;






public class ExamQuestion2Test {

    private ExamQuestion2 app;

    @Before
    public void setUp() {
        app = new ExamQuestion2();
        // Initialize the form fields with valid data
        app.movieComboBox.setSelectedItem("Napoleon");
        app.ticketPriceField.setText("50.0");
        app.ticketCountField.setText("2");
    }//(Nalwade.K,2023)

    
    
    
    
    
    
    
    
    
    
    
    
    // Test if the "Process" action processes valid data and generates the correct report
    @Test
    public void testActionPerformed_ProcessValidData() {
        // Simulate "Process" action
        ActionEvent processEvent = new ActionEvent(app, ActionEvent.ACTION_PERFORMED, "Process");
        app.actionPerformed(processEvent);

        // Verify that the report area contains the expected text
        String reportText = app.reportArea.getText();
        assertTrue("Report should contain the movie name", reportText.contains("Napoleon"));
        assertTrue("Report should contain the number of tickets", reportText.contains("Tickets: 2"));
        assertTrue("Report should contain the ticket price", reportText.contains("Price per Ticket: 50.0"));

        // Verify the total price calculation with 14% VAT (50 * 2 * 1.14 = 114.00)
        assertTrue("Report should contain the total price with VAT", reportText.contains("Total Price (incl. VAT): 114.00"));
    }
//(Nalwade.K,2023)
    
    
    
    
    
    
    
    
    
    // Test that the report is saved to report.txt after processing
    @Test
    public void testSaveReportToFile() {
        // Trigger the process action
        ActionEvent processEvent = new ActionEvent(app, ActionEvent.ACTION_PERFORMED, "Process");
        app.actionPerformed(processEvent);

        // Check if the file "report.txt" exists and contains the expected content
        File reportFile = new File("report.txt");
        assertTrue("Report file should be created", reportFile.exists());

        try (BufferedReader reader = new BufferedReader(new FileReader(reportFile))) {
            String fileContent = reader.readLine();
            assertTrue("File should contain the movie name", fileContent.contains("Napoleon"));

            // Read next line and verify the total price with VAT
            String totalLine = reader.readLine();
            assertTrue("File should contain the total price with VAT", totalLine.contains("Total Price (incl. VAT): 114.00"));
        } catch (IOException e) {
            fail("Could not read the report file: " + e.getMessage());
        }
    }//(Nalwade.K,2023)

    
    
    
    
    
    
    
    
    // Test if invalid data (negative ticket price) is handled correctly
    @Test
    public void testActionPerformed_InvalidTicketPrice() {
        // Set invalid ticket price (negative value)
        app.ticketPriceField.setText("-50.0");

        // Simulate "Process" action
        ActionEvent processEvent = new ActionEvent(app, ActionEvent.ACTION_PERFORMED, "Process");
        app.actionPerformed(processEvent);

        // Verify that the report area is empty due to validation failure
        assertEquals("Report area should be empty if validation fails", "", app.reportArea.getText());
    }//(Nalwade.K,2023)

    
    
    
    
    
    
    
    
    
    
    
    
    
    // Test if invalid data (zero number of tickets) is handled correctly
    @Test
    public void testActionPerformed_InvalidNumberOfTickets() {
        // Set zero number of tickets
        app.ticketCountField.setText("0");

        // Simulate "Process" action
        ActionEvent processEvent = new ActionEvent(app, ActionEvent.ACTION_PERFORMED, "Process");
        app.actionPerformed(processEvent);

        // Verify that the report area is empty due to validation failure
        assertEquals("Report area should be empty if validation fails", "", app.reportArea.getText());
    }//(Nalwade.K,2023)

    
    
    
    
    
    
    
    
    
    
    
    // Test if invalid data (empty movie name) is handled correctly
    @Test
    public void testActionPerformed_InvalidMovieName() {
        // Set empty movie name
        app.movieComboBox.setSelectedItem("");

        // Simulate "Process" action
        ActionEvent processEvent = new ActionEvent(app, ActionEvent.ACTION_PERFORMED, "Process");
        app.actionPerformed(processEvent);

        // Verify that the report area is empty due to validation failure
        assertEquals("Report area should be empty if validation fails", "", app.reportArea.getText());
    }//(Nalwade.K,2023)

    
    
    
    
    
    
    
    
    
    // Test if the "Clear" action clears all fields
    @Test
    public void testClearFields() {
        // Set some data in the fields
        app.movieComboBox.setSelectedItem("Oppenheimer");
        app.ticketPriceField.setText("100.0");
        app.ticketCountField.setText("3");

        // Simulate "Clear" action
        ActionEvent clearEvent = new ActionEvent(app, ActionEvent.ACTION_PERFORMED, "Clear");
        app.actionPerformed(clearEvent);

        // Verify that all fields are cleared
        assertEquals("Movie combo box should be reset", "Napoleon", app.movieComboBox.getSelectedItem());
        assertEquals("Ticket price field should be cleared", "", app.ticketPriceField.getText());
        assertEquals("Ticket count field should be cleared", "", app.ticketCountField.getText());
        assertEquals("Report area should be empty", "", app.reportArea.getText());
    }
}
//(Nalwade.K,2023)
/* 

Code Attribution 

Nalwade, Kunal 2023. Accessed online at: https://www.freecodecamp.org/news/java-unit-testing/
Turtorials point 2024. Accessed online at: https://www.tutorialspoint.com/junit/index.htm


*/
