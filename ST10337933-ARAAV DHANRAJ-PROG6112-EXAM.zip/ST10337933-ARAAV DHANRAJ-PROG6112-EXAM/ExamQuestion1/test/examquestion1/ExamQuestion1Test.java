/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package examquestion1;

import org.junit.Test; //(TurtorialsPoint, 2024)
import static org.junit.Assert.*;//(TurtorialsPoint, 2024)

public class ExamQuestion1Test {

    
    
    
    
    
    @Test
    public void testTotalMovieSales() { //(TurtorialsPoint, 2024)
        
        MovieTickets movieTickets = new MovieTickets();
        
        int[] sales = {1000, 2000, 3000};
        int expectedTotal = 6000;
        int actualTotal = movieTickets.TotalMovieSales(sales);
        
        assertEquals(expectedTotal, actualTotal);
        
    }//(Nalwade.K,2023)
  
    
    
    
    
    
    
    
    
    @Test
    public void testTopMovie() { //(TurtorialsPoint, 2024)
        
        
        MovieTickets movieTickets = new MovieTickets();
        
        String[] movies = {"Movie A", "Movie B", "Movie C"};
        int[] sales = {1500, 3000, 2500}; // Movie B has the highest sales
        String expectedTopMovie = "Movie B";
        String actualTopMovie = movieTickets.TopMovie(movies, sales);
        
        assertEquals(expectedTopMovie, actualTopMovie);
        
        
        
        
    }//(Nalwade.K,2023)

    
    
    
    
    
    
    
    
    
    @Test
    public void testTopMovieWithEqualSales() { //(TurtorialsPoint, 2024)
        
        
        
        
        
        MovieTickets movieTickets = new MovieTickets();
        
        String[] movies = {"Movie A", "Movie B"};
        int[] sales = {2000, 2000}; // Both movies have equal sales
        String expectedTopMovie = "Movie A"; // Should return the first one
        String actualTopMovie = movieTickets.TopMovie(movies, sales);
        
        assertEquals(expectedTopMovie, actualTopMovie);
        
        
        
        
    }//(Nalwade.K,2023)
}





/* 

Code Attribution 

Nalwade, Kunal 2023. Accessed online at: https://www.freecodecamp.org/news/java-unit-testing/
Turtorials point 2024. Accessed online at: https://www.tutorialspoint.com/junit/index.htm


*/