package examquestion1;

import java.util.Scanner; //(w3schools,2024)


interface IMovieTickets {
    int TotalMovieSales(int[] movieTicketSales);
    String TopMovie(String[] movies, int[] totalSales);
}
//(w3schools,2024)




class MovieTickets implements IMovieTickets {

    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sales : movieTicketSales) {
            total += sales;
        }
        return total;
    }
    
    //(w3schools,2024)
    
    

    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[maxIndex]) {
                maxIndex = i;
            }
        }
        return movies[maxIndex];
    }
}



//(w3schools,2024)


public class ExamQuestion1 {

    
    
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); //(w3schools,2024)
        
        
        ExamQuestion1 app = new ExamQuestion1();
        app.run(scanner);//(w3schools,2024)
        scanner.close();//(w3schools,2024)
        
        
    }

    
    
    
    
    // the below code asks the user to enter the number of movies 
    public void run(Scanner scanner) { //(w3schools,2024)
        System.out.print("Enter the number of movies: ");
        int numberOfMovies = scanner.nextInt();
        scanner.nextLine(); //(w3schools,2024)

        
        
        
        String[] movies = new String[numberOfMovies];
        int[][] ticketSales = new int[numberOfMovies][3]; // For Jan, Feb, Mar

        // the below code asks the user to enter the names of the movies aswell as the number of tickets sold for the months 
        
        
        for (int i = 0; i < numberOfMovies; i++) {
            System.out.print("Enter the name of movie " + (i + 1) + ": ");
            movies[i] = scanner.nextLine();

            
            
            
            
            
            System.out.print("Enter ticket sales for January: ");
            ticketSales[i][0] = scanner.nextInt(); //(w3schools,2024)
            System.out.print("Enter ticket sales for February: ");
            ticketSales[i][1] = scanner.nextInt(); //(w3schools,2024)
            System.out.print("Enter ticket sales for March: ");
            ticketSales[i][2] = scanner.nextInt(); //(w3schools,2024)
            scanner.nextLine(); //(w3schools,2024)
            //asking the user for the number of tickets sold 
        }
        
        
        
        
        
        
        
        

        MovieTickets movieTickets = new MovieTickets();
        int[] totalSales = new int[movies.length];//(w3schools,2024)

        
        
        
        
        
        
        System.out.println("\nMovie Ticket Sales Report (Jan - Mar 2024):"); //(w3schools,2024)
        System.out.println("-------------------------------------------------"); //(w3schools,2024)
        System.out.printf("%-15s %-10s %-10s %-10s %-10s%n", "Movie", "January", "February", "March", "Total"); //(w3schools,2024)
        System.out.println("-------------------------------------------------");//(w3schools,2024)

        
        
        
        
        
        
        
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = movieTickets.TotalMovieSales(ticketSales[i]);
            System.out.printf("%-15s %-10d %-10d %-10d %-10d%n", movies[i], ticketSales[i][0], ticketSales[i][1], ticketSales[i][2], totalSales[i]); //(w3schools,2024)
        }

        //the above code calculates the number of ticket sales 
        
        
        
        
        
        
        
        
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        System.out.println("-------------------------------------------------"); //(w3schools,2024)
        System.out.println("Top Performing Movie: " + topMovie); //(w3schools,2024)
        
        //the above code displays the top performing movie over the course of the selected months 
    }
}






/* 
Source Attribution:
w3schools,2024. Scanner Java. Accessed online at: https://www.w3schools.com/java/java_user_input.asp
w3Schools, 2024. Display/Print. Accessed online at: https://www.w3schools.com/java/java_variables_print.asp
w3schools, 2024. Java Arrays. Accessed online at: https://www.w3schools.com/java/java_arrays.asp

*/